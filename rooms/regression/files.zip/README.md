# Resolver regression set

Run before shipping any change inside the pure region (`/*__PURE_START__*/` … `/*__PURE_END__*/`),
in `--prev` mode against the previous build, each room with and without `--noseams`:

    node tools/resolver_harness.js --app tessera.html --prev tessera_prev.html --rules rooms/regression/tester-2_rules.json --room rooms/regression/tester-2_room.json
    node tools/resolver_harness.js --app tessera.html --prev tessera_prev.html --rules rooms/regression/tester-2_rules.json --room rooms/regression/tester-2_room.json --noseams
    (same for tester-2_room_5.json, and for newtemp_room.json with newtemp_rules.json)

| File | What it covers |
|---|---|
| `tester-2_rules.json` + `tester-2_4.png` | James's 5×5 "Tech" layout with rim joints on (`RIM_JOINTS`, `RIM_WEDGES: terminate`, `CADENCE_ANCHOR: run`) |
| `tester-2_room.json` | three inner seams; proves the B4/B2 corner rule (v6.121.3) |
| `tester-2_room_5.json` | a seam ending beside a pillar leg; proves the strip rule (v6.121.4) — only four cells may differ from a build without it |
| `newtemp_rules.json` + `newtemp.png` | the 5×5 template on the 8×8 block-grid art, no seams |
| `newtemp_room.json` | 33 slope runs, all three grads, both faces — the slope regression room |

Rules of thumb: `--noseams` must print IDENTICAL for any change that only touches seams. A seam
change should move only the cells it targets; name each one in the delivery note.
